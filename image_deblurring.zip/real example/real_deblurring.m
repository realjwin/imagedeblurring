%Written By: Jacob Winick
%About: Compares different deconvolution methods with different noise
%levels. Compares Wiener filter, Lucy-Richardson, and blind
%deconvolution

%Show wiener filter with different noise levels, and psfs, show that if you
%know the exact psf it defaults to normal, problem is how to do we choose
%noise level?

%lucy-richardson try different psfs and different # of iterations, show
%that it gives a better answer than wiener filter with diff # of iterations

%blind deconvolution, try different psfs (sizes), show if you use exact psf, what
%happens? try diff # of iterations & edgetaper
%----------------------DELETE---------------------------------------------%

%Written By: Jacovb Winick
%About: This explores both the Wiener filter and blind deconvolution to
%deblur real images blurred with a Canon T5i camera. We will explore
%different estimated PSFs and different noise levels and/or iterations to
%acheive the best result


y = rgb2gray(imread('note_blurred_o.jpg'));

%psf1 = fspecial('disk', 54);
%x = deconvwnr(y, psf1, 0.005);
%imshow(x)

%use this with blind
psf2 = fspecial('disk', 54);
x = deconvblind(y, psf2, 18);
imshow(x)
