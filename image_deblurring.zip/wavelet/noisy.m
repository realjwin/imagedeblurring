%Written by Patrick Leavy

% Load the blurred image taken with out of focus
% camera, and convert to grayscale.
W = imread('IMG_1280.jpg');
Z = rgb2gray(W);

% Add artificial noise. Chose standard gaussian
% white noise.
Y_2 = imnoise(Z,'gaussian');

% Using blind deconvolution to produce an unblurred 
% photo. Note Hp was chosen as a 30x40 matrix by 
% trial and error. This produced the best results
Hp= ones(30,40);
[Y2,H2] = deconvblind(Y_2, Hp);

% Plots
figure
subplot(2,1,1)
imshow(Y_2)
title('Blurred with Added Gaussian White Noise')
subplot(2,1,2)
imshow(Y2)
title('Blind Deconvolution with Noise')


