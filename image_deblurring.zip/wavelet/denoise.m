%Written by Patrick Leavy

% Load the image denoised using The Stationary Wavelet
% Transform Toolbox provided by Matlab and convert to 
% grayscale
W = imread('1280denos.jpg');
Z = rgb2gray(W);

% Using blind deconvolution to produce an unblurred 
% photo. Note Hp was chosen as a 30x40 matrix by 
% trial and error. This produced the best results
Hp = ones(30, 40);
[Y1,H1] = deconvblind(Z,Hp);


% Plots
figure
subplot(2,1,1)
imshow(Z)
title('Blurred with Noise Reduction with Wavelets')
subplot(2,1,2)
imshow(Y1)
title('Blind Deconvolution')


