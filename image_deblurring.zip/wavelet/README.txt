//Written by Patrick Leavy

//
In order to run the Blind Deconvolution with Wavelet denoising download

1280denos.jpg, IMG_1280.jpg, wavelet.jpg, denoise.m, and noisy.m and place all the files

in a common folder.

//
To run the demonstration showing the effects of blind deconvolution on a noisy

image, run noisy.m

//
To run the demonstration showing the effects of blind deconcolution on an image 

after noise reduction using the Stationary Wavelet Transform Toolbox in Matlab.

For simplicity the denoised photo has been provided. This can be recreated using the 

presets depicted in the Toolboc image provided. 