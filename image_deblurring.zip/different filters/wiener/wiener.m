% Written by Patrick Leavy
close all; 
clear all; 

% Read in the image and convert it to grayscale
y = rgb2gray((imread('note.jpg')));
y = im2double(y); 

% Create the Point Spread Function (Blur Kernel)
PSF = fspecial('disk', 8);

% Convolve The Original Image and the Blur Kernel
blur = imfilter(y, PSF, 'circular','conv');

% Use the wiener filter to deconvolve with no noise 
X = deconvwnr(blur,PSF,0);

figure
subplot(341)
imshow(y)
title('Original Image')

subplot(345)
imshow(blur)
title('Blurred Image')

subplot(346)
imshow(X)
title('Deconvolution using Wiener Filter and No Noise')

% Use a false PSF to deconvolve the blurred image with the wiener filter
PSFfalse = fspecial('disk', 9);

Xfalse = deconvwnr(blur,PSFfalse,0);

subplot(347)
imshow(Xfalse)
title('Deconvolution using Wiener Filter with Wrong PSF')

% Use the same false PSF and use false noise in the wiener filter
Xfalse2 = deconvwnr(blur,PSFfalse, 0.01);

subplot(348)
imshow(Xfalse2)
title('Deconvolution using Wiener Filter with Wrong PSF and Wrong Noise')

% Add noise to the blurred image
noise = imnoise(blur, 'gaussian', 0,.00001);

subplot(349)
imshow(noise)
title('Blurred Image with Noise')

% Use the wiener filter with the correct NSR to deconvolve the blurred image with
% noise
NSR = .00001/var(noise(:));
X2 = deconvwnr(blur,PSF,NSR);

subplot(3,4,10)
imshow(X2)
title('Deconvolution using Weiner Filter and Correct Noise')

