README

Most of the files are self-explanatory. Open the file, run the file and an output will appear. The files are commented with what they do and most graphs have titles on each image for added calrity. Please reach out to us (winickj@umich.edu) if you have any questions.