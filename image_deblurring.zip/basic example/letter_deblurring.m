% Author: Travis Bowers
% Date:   12/8/2014
% This script will read in a photograph of a handwritten note. This photograph is 
% convolved against three different blur kernels. This simulates blurring of the
% image. Next the image blurred images and their corresponding blur kernels
% are transformed into the frequency domain using the fft2() function in MATLAB. 
% Next the freqency domain representations of the blurred images are divided
% by the frequency domain representations of their blur kernels. Then the images 
% are transformed back into the time domain. The images are plotted in a subplot
% and the resulting deblurring can be qualitatively observed.

close all;
clear all;

x = rgb2gray(imread('note.jpg'));
x = im2double(x);
subplot(4,3,1);
imshow(x)
title('original image'); 
%3 different PSFs
h1 = fspecial('gaussian', [5,5],3);
subplot(4,3,5)
imshow(h1*22);
title('Blur kernel for gaussian with variance=3');

h2 = fspecial('motion', 45,50);
subplot(4,3,8);
imshow(h2.*255);
title('Blur kernel of motion blur of length=50 and theta=45');

h3 = fspecial('disk', 8);
subplot(4,3,11)
imshow(h3.*255);
title('Blur kernel for a disk blur of radius=8');

%gaussian, motion, disk
%a gaussian of shape (5,5) will work, but a gaussian of (6,6)
%won't 

y1= conv2(x,h1);
subplot(4,3,4)
imshow(y1);
title('Gaussian blurred image with variance = 40')

y2= conv2(x,h2);
subplot(4,3,7)
imshow(y2)
title('Motion blurred image with LEN = 50 and THETA = 45')


y3 = conv2(x,h3);
subplot(4,3,10)
imshow(y3);
title('Disk blurred image with Radius=8')



%convolve image with psf
%or use imfilter w/ 'conv'






X =fft2(x,550,550);

newh = zeros(size(y1));
newh2 = zeros(size(y2));
newh3 = zeros(size(y3)); 

sz = size(h1);
sz2 = size(h2);
sz3 = size(h3);

newh(1:sz(1),1:sz(2)) = h1;
newh2(1:sz2(1),1:sz2(2)) = h2;
newh3(1:sz3(1),1:sz3(2)) = h3;

H1 = fft2(newh);
H2 = fft2(newh2);
H3 = fft2(newh3);



Y= fft2(y1);
Y2= fft2(y2);
Y3= fft2(y3);

%use simple X = Y/H to get back original image

Xtest = Y./H1;
X2test = Y2./H2;
X3test = Y3./H3;


%compute inverse fft to return the image to the time domain
xTest = ifft2(Xtest);
x2Test = ifft2(X2test);
x3Test = ifft2(X3test); 
%plot deblurred images
subplot(4,3,6);
imshow(xTest);
title('Inverse ifft2 of the gausian blurred image divided by its PSF');

subplot(4,3,9)
imshow(x2Test);
title('Inverse ifft2 of the motion blurred image divided by its PSF');

subplot(4,3,12)
imshow(x3Test);
title('Inverse ifft2 of the disk blurred image divided by its PSF');



                                              
