%written by: Colin Nangle
%about: This matlab script demonstrates the large effect noise has on
%deblurring an image with a known Point Spread Function (PSF). It process
%an unblurred image of a piece of paper with text written on it in the
%following order. 
%       1. preprocessing of the image to convert the image to grayscale and
%       to represent the image in double form. 
%       2. Blurring of the image using the conv2 function and a defined
%       disk PSF. 
%       3. Adding variable levels of noise to the blurred image. 
%       4. deconvolving the blurred-noisy images and comparing the quality
%       of the deblurred image for different noise values. 

close all; 
clear all; 
%image preprocessing
y = rgb2gray((imread('note.jpg')));
y = im2double(y); 

%take disk psf
PSF = fspecial('disk', 8);

%convolve image with psf
%or use imfilter w/ 'conv'
yblur = conv2(y,PSF); 

%plot original image
figure(); 
subplot(2,1,1); imshow(y); title('actual image'); 
%plot unnoisy blurred image
subplot(2,1,2); imshow(yblur); title('blurred image');  

%add noise at different levels to the blurred image
y2BlurredNoisy = imnoise(yblur,'gaussian',0,.00000000001);
y3BlurredNoisy = imnoise(imfilter(yblur,PSF),'gaussian',0,.0001);
y4BlurredNoisy = imnoise(imfilter(yblur,PSF), 'gaussian', 0,.001); 

%plot different noisy blurred images
figure(); 
subplot(2,4,1); imshow(yblur); title('no noise');
subplot(2,4,2); imshow(y2BlurredNoisy); title('Gaussian white noise of variance 10^{-11}'); 
subplot(2,4,3); imshow(y3BlurredNoisy); title('Gaussian white noise of variance 10^{-4}');
subplot(2,4,4); imshow(y4BlurredNoisy); title('Gaussian white noise of variance 10^{-3}');

%use simple X = Y/H to get back original image
%show how much noise affects it
Y1 = fft2(yblur); 
Y2 = fft2(y2BlurredNoisy);
Y3 = fft2(y3BlurredNoisy); 
Y4 = fft2(y4BlurredNoisy); 

%zero pad the psf to match the size of the blurred image
%noisy images are all the same size, thus do not require unique PSF's
newh = zeros(size(yblur)); 
psfsize = size(PSF); 
newh(1: psfsize(1), 1:psfsize(2))= PSF;
H = fft2(newh); 

%use simple X = Y/H to get back original image
%show how much noise affects it
y1deblurred = ifft2(Y1./H);
y2deblurred = ifft2(Y2./H); 
y3deblurred = ifft2(Y3./H); 
y4deblurred = ifft2(Y4./H); 

%plot deblurred images

subplot(2,4,5);imshow(y1deblurred);title('no noise');
subplot(2,4,6);imshow(y2deblurred);title('Gaussian white noise of variance 10^{-11}');
subplot(2,4,7);imshow(y3deblurred);title('Gaussian white noise of variance 10^{-4}');
subplot(2,4,8);imshow(y4deblurred);title('Gaussian white noise of variance 10^{-3}');





