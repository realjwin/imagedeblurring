%Written by: Jacob Winick
%About: Implements the basic Ayers and Dainty model of blind deconvolution.
%This model takes an image, blurs it, then uses the known size of the psf
%as the starting point to do Ayers and Dainty blind deconvolution. This
%model does not converge because it does not implement sophisticated
%bounding functions to force convergence.

%clear current matlab workspace
clear all;
clc;

%input blurred image
filename = 'note.jpg';
c_unblurred = double(rgb2gray(imread(filename)));
size = size(c_unblurred);

%blur image
psf = fspecial('disk', 8);
c = conv2(c_unblurred, psf, 'same');


%-------------------------------------------------------------------------%
%Run 10 iterations with actual PSF to show that even if you have actual PSF
%you cannot converge
%-------------------------------------------------------------------------%

%use actual psf
f = psf;

%N is rows/cols for DFT, must be larger than size(c) + size(f);
%We want to use the same size DFT for both because we want the frequencies
%to match up in the discrete time domain, otherwise we have different size
%DFTs
N=550;

%# of iterations
iterations = 10;

%C is fft of blurred image
%F is fft of psf
%G is what we are trying to get
C = fft2(c, N, N);

for i = 0:iterations,
    F = fft2(f, N, N);
    Finv = inv(F);
    G = C.*Finv;
    g = ifft2(G, N, N);
    g=abs(g);
    g(g<0) = 0;
    
    G = fft2(g, N, N);
    Ginv = inv(G);
    F = C.*Ginv;
    f = ifft2(F, N, N);
    f = abs(f);
    f(f<0) = 0;
end

F = fft2(f, N, N);
Finv = inv(F);
G = C.*Finv;
g = ifft2(G, N, N);
g=abs(g);
g(g<0) = 0;
output = uint8(g);
c_deblurred = output(1:size(1),1:size(2));

subplot(1,3,1)
imshow(uint8(c_unblurred));
title('Original unblurred image');

subplot(1,3,2)
imshow(uint8(c));
title('Blurred image with fspecial(''disk'', 8)')

subplot(1,3,3)
imshow(uint8(c_deblurred));
title('Deblurred image with Ayers and Dainty, does not converge')

